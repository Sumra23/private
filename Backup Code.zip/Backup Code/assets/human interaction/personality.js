class Human {

    constructor(name,dob,location,proxy,timeZone,address){

    }

    interest(youtube,google,websites){

    }

    lifestyle (morning,afternoon,night) {

    }

    lifecycle (Active,sleep) {

    }

    actions(steps){

    
        
    }

    interpretation (key) {

    }

}